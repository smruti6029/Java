package Com.SpringCode;

public class Show {

	
	public static void main(String[] args) {
		final int i;
		i=10;
		System.out.println(i);

	}
}
